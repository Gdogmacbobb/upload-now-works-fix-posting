import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/about_section_widget.dart';
import './widgets/donation_button_widget.dart';
import './widgets/profile_header_widget.dart';
import './widgets/video_context_menu_widget.dart';
import './widgets/video_grid_widget.dart';

class PerformerProfile extends StatefulWidget {
  const PerformerProfile({super.key});

  @override
  State<PerformerProfile> createState() => _PerformerProfileState();
}

class _PerformerProfileState extends State<PerformerProfile>
    with TickerProviderStateMixin {
  late TabController _tabController;
  bool isFollowing = false;
  bool isRefreshing = false;

  // Mock performer data
  final Map<String, dynamic> performerData = {
    "id": "performer_001",
    "name": "Marcus \"The Beat\" Rodriguez",
    "avatar":
        "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400",
    "bio":
        "Street drummer bringing NYC rhythms to life 🥁 Performing in Times Square, Central Park, and Brooklyn Bridge. Follow for daily beats and street vibes! #NYCStreetMusic #DrumLife",
    "verificationStatus": "verified",
    "followersCount": 12500,
    "followingCount": 89,
    "videoCount": 47,
    "totalDonations": 2850,
    "totalViews": 450000,
    "totalLikes": 28500,
    "joinDate": "2023-03-15T10:30:00Z",
    "performanceTypes": ["Drumming", "Percussion", "Street Performance"],
    "frequentLocations": [
      "Times Square",
      "Central Park",
      "Brooklyn Bridge",
      "Washington Square Park"
    ],
    "schedule": [
      {
        "day": "Monday - Friday",
        "time": "6:00 PM - 9:00 PM",
        "location": "Times Square (Red Steps)"
      },
      {
        "day": "Saturday",
        "time": "2:00 PM - 8:00 PM",
        "location": "Central Park (Bethesda Fountain)"
      },
      {
        "day": "Sunday",
        "time": "12:00 PM - 6:00 PM",
        "location": "Brooklyn Bridge (Manhattan Side)"
      }
    ],
    "socialMedia": {
      "instagram": "@marcusthebeat",
      "tiktok": "@marcusbeats",
      "youtube": "Marcus Rodriguez Music"
    }
  };

  // Mock videos data
  final List<Map<String, dynamic>> videosData = [
    {
      "id": "video_001",
      "title": "Epic Drum Solo in Times Square",
      "thumbnailUrl":
          "https://images.pexels.com/photos/1407322/pexels-photo-1407322.jpeg?auto=compress&cs=tinysrgb&w=400",
      "duration": 45,
      "viewCount": 15200,
      "likeCount": 1250,
      "uploadDate": "2025-01-25T18:30:00Z"
    },
    {
      "id": "video_002",
      "title": "Crowd Goes Wild - Central Park Performance",
      "thumbnailUrl":
          "https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=400",
      "duration": 38,
      "viewCount": 8900,
      "likeCount": 720,
      "uploadDate": "2025-01-23T16:45:00Z"
    },
    {
      "id": "video_003",
      "title": "Rainy Day Beats Under Brooklyn Bridge",
      "thumbnailUrl":
          "https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=400",
      "duration": 52,
      "viewCount": 12800,
      "likeCount": 980,
      "uploadDate": "2025-01-22T14:20:00Z"
    },
    {
      "id": "video_004",
      "title": "Collaboration with Street Dancer",
      "thumbnailUrl":
          "https://images.pexels.com/photos/1540406/pexels-photo-1540406.jpeg?auto=compress&cs=tinysrgb&w=400",
      "duration": 60,
      "viewCount": 22100,
      "likeCount": 1850,
      "uploadDate": "2025-01-20T19:15:00Z"
    },
    {
      "id": "video_005",
      "title": "Morning Warm-up Session",
      "thumbnailUrl":
          "https://images.pexels.com/photos/1699161/pexels-photo-1699161.jpeg?auto=compress&cs=tinysrgb&w=400",
      "duration": 28,
      "viewCount": 5600,
      "likeCount": 420,
      "uploadDate": "2025-01-19T09:30:00Z"
    },
    {
      "id": "video_006",
      "title": "Sunset Beats at Washington Square",
      "thumbnailUrl":
          "https://images.pexels.com/photos/1644888/pexels-photo-1644888.jpeg?auto=compress&cs=tinysrgb&w=400",
      "duration": 41,
      "viewCount": 9800,
      "likeCount": 750,
      "uploadDate": "2025-01-18T20:00:00Z"
    }
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.darkTheme.scaffoldBackgroundColor,
      body: Stack(
        children: [
          RefreshIndicator(
            onRefresh: _handleRefresh,
            color: AppTheme.primaryOrange,
            backgroundColor: AppTheme.surfaceDark,
            child: CustomScrollView(
              slivers: [
                // App Bar
                SliverAppBar(
                  backgroundColor: AppTheme.darkTheme.scaffoldBackgroundColor,
                  foregroundColor: AppTheme.textPrimary,
                  elevation: 0,
                  floating: true,
                  snap: true,
                  leading: IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: CustomIconWidget(
                      iconName: 'arrow_back',
                      color: AppTheme.textPrimary,
                      size: 24,
                    ),
                  ),
                  actions: [
                    IconButton(
                      onPressed: _handleShare,
                      icon: CustomIconWidget(
                        iconName: 'share',
                        color: AppTheme.textPrimary,
                        size: 24,
                      ),
                    ),
                    PopupMenuButton<String>(
                      icon: CustomIconWidget(
                        iconName: 'more_vert',
                        color: AppTheme.textPrimary,
                        size: 24,
                      ),
                      color: AppTheme.surfaceDark,
                      onSelected: _handleMenuAction,
                      itemBuilder: (context) => [
                        PopupMenuItem(
                          value: 'block',
                          child: Row(
                            children: [
                              CustomIconWidget(
                                iconName: 'block',
                                color: AppTheme.accentRed,
                                size: 20,
                              ),
                              SizedBox(width: 3.w),
                              Text(
                                "Block User",
                                style: AppTheme.darkTheme.textTheme.bodyMedium
                                    ?.copyWith(
                                  color: AppTheme.accentRed,
                                ),
                              ),
                            ],
                          ),
                        ),
                        PopupMenuItem(
                          value: 'report',
                          child: Row(
                            children: [
                              CustomIconWidget(
                                iconName: 'report',
                                color: AppTheme.accentRed,
                                size: 20,
                              ),
                              SizedBox(width: 3.w),
                              Text(
                                "Report Profile",
                                style: AppTheme.darkTheme.textTheme.bodyMedium
                                    ?.copyWith(
                                  color: AppTheme.accentRed,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),

                // Profile Header
                SliverToBoxAdapter(
                  child: ProfileHeaderWidget(
                    performerData: performerData,
                    isFollowing: isFollowing,
                    onFollowTap: _handleFollowTap,
                  ),
                ),

                // Tab Bar
                SliverPersistentHeader(
                  pinned: true,
                  delegate: _SliverTabBarDelegate(
                    TabBar(
                      controller: _tabController,
                      tabs: const [
                        Tab(text: "Videos"),
                        Tab(text: "About"),
                      ],
                    ),
                  ),
                ),

                // Tab Content
                SliverFillRemaining(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      // Videos Tab
                      VideoGridWidget(
                        videos: videosData,
                        onVideoTap: _handleVideoTap,
                        onVideoLongPress: _handleVideoLongPress,
                      ),
                      // About Tab
                      AboutSectionWidget(
                        performerData: performerData,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Floating Donation Button
          DonationButtonWidget(
            onDonationTap: _handleDonationComplete,
          ),
        ],
      ),
    );
  }

  Future<void> _handleRefresh() async {
    setState(() {
      isRefreshing = true;
    });

    // Simulate refresh delay
    await Future.delayed(const Duration(seconds: 1));

    if (mounted) {
      setState(() {
        isRefreshing = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "Profile updated",
            style: AppTheme.darkTheme.textTheme.bodyMedium,
          ),
          backgroundColor: AppTheme.surfaceDark,
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  void _handleFollowTap() {
    HapticFeedback.lightImpact();
    setState(() {
      isFollowing = !isFollowing;
      if (isFollowing) {
        performerData["followersCount"] =
            (performerData["followersCount"] as int) + 1;
      } else {
        performerData["followersCount"] =
            (performerData["followersCount"] as int) - 1;
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: isFollowing ? 'person_add' : 'person_remove',
              color: AppTheme.primaryOrange,
              size: 20,
            ),
            SizedBox(width: 2.w),
            Text(
              isFollowing
                  ? "Now following ${performerData["name"]}"
                  : "Unfollowed ${performerData["name"]}",
              style: AppTheme.darkTheme.textTheme.bodyMedium,
            ),
          ],
        ),
        backgroundColor: AppTheme.surfaceDark,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _handleVideoTap(Map<String, dynamic> video) {
    HapticFeedback.lightImpact();
    // Navigate to full-screen video player
    AppRoutes.pushNamed(
      context,
      AppRoutes.videoPlayer,
      arguments: video,
    );
  }

  void _handleVideoLongPress(Map<String, dynamic> video) {
    HapticFeedback.mediumImpact();
    VideoContextMenuWidget.show(
      context,
      video,
      onSave: () => _handleVideoSave(video),
      onShare: () => _handleVideoShare(video),
      onReport: () => _handleVideoReport(video),
    );
  }

  void _handleVideoSave(Map<String, dynamic> video) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'bookmark',
              color: AppTheme.primaryOrange,
              size: 20,
            ),
            SizedBox(width: 2.w),
            Text(
              "Video saved to collection",
              style: AppTheme.darkTheme.textTheme.bodyMedium,
            ),
          ],
        ),
        backgroundColor: AppTheme.surfaceDark,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _handleVideoShare(Map<String, dynamic> video) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'share',
              color: AppTheme.primaryOrange,
              size: 20,
            ),
            SizedBox(width: 2.w),
            Text(
              "Video link copied to clipboard",
              style: AppTheme.darkTheme.textTheme.bodyMedium,
            ),
          ],
        ),
        backgroundColor: AppTheme.surfaceDark,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _handleVideoReport(Map<String, dynamic> video) {
    // Report handling is done in VideoContextMenuWidget
  }

  void _handleShare() {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'share',
              color: AppTheme.primaryOrange,
              size: 20,
            ),
            SizedBox(width: 2.w),
            Text(
              "Profile link copied to clipboard",
              style: AppTheme.darkTheme.textTheme.bodyMedium,
            ),
          ],
        ),
        backgroundColor: AppTheme.surfaceDark,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _handleMenuAction(String action) {
    switch (action) {
      case 'block':
        _showBlockDialog();
        break;
      case 'report':
        _showReportDialog();
        break;
    }
  }

  void _showBlockDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surfaceDark,
        title: Text(
          "Block ${performerData["name"]}?",
          style: AppTheme.darkTheme.textTheme.titleLarge,
        ),
        content: Text(
          "You won't see their content and they won't be able to find your profile.",
          style: AppTheme.darkTheme.textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Cancel",
              style: AppTheme.darkTheme.textTheme.labelLarge?.copyWith(
                color: AppTheme.textSecondary,
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context); // Return to previous screen
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    "User blocked",
                    style: AppTheme.darkTheme.textTheme.bodyMedium,
                  ),
                  backgroundColor: AppTheme.surfaceDark,
                ),
              );
            },
            child: Text(
              "Block",
              style: AppTheme.darkTheme.textTheme.labelLarge?.copyWith(
                color: AppTheme.accentRed,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showReportDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surfaceDark,
        title: Text(
          "Report Profile",
          style: AppTheme.darkTheme.textTheme.titleLarge,
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Why are you reporting this profile?",
              style: AppTheme.darkTheme.textTheme.bodyMedium,
            ),
            SizedBox(height: 2.h),
            ...[
              "Fake account",
              "Inappropriate content",
              "Spam or scam",
              "Harassment",
              "Other"
            ].map((reason) => InkWell(
                  onTap: () {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          "Report submitted. Thank you for helping keep YNFNY safe.",
                          style: AppTheme.darkTheme.textTheme.bodyMedium,
                        ),
                        backgroundColor: AppTheme.surfaceDark,
                        duration: const Duration(seconds: 3),
                      ),
                    );
                  },
                  child: Container(
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(vertical: 1.5.h),
                    child: Text(
                      reason,
                      style: AppTheme.darkTheme.textTheme.bodyMedium,
                    ),
                  ),
                )),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Cancel",
              style: AppTheme.darkTheme.textTheme.labelLarge?.copyWith(
                color: AppTheme.textSecondary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _handleDonationComplete() {
    // Donation completion is handled in DonationButtonWidget
  }
}

class _SliverTabBarDelegate extends SliverPersistentHeaderDelegate {
  final TabBar _tabBar;

  _SliverTabBarDelegate(this._tabBar);

  @override
  double get minExtent => _tabBar.preferredSize.height;

  @override
  double get maxExtent => _tabBar.preferredSize.height;

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: AppTheme.darkTheme.scaffoldBackgroundColor,
      child: _tabBar,
    );
  }

  @override
  bool shouldRebuild(_SliverTabBarDelegate oldDelegate) {
    return false;
  }
}
