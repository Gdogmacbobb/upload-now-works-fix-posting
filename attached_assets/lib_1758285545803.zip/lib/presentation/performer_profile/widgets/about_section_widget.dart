import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class AboutSectionWidget extends StatelessWidget {
  final Map<String, dynamic> performerData;

  const AboutSectionWidget({
    super.key,
    required this.performerData,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Bio Section
          if (performerData["bio"] != null &&
              (performerData["bio"] as String).isNotEmpty)
            _buildSection(
              "About",
              Text(
                performerData["bio"] as String,
                style: AppTheme.darkTheme.textTheme.bodyMedium,
              ),
            ),

          // Performance Details
          if (performerData["performanceTypes"] != null)
            _buildSection(
              "Performance Types",
              Wrap(
                spacing: 2.w,
                runSpacing: 1.h,
                children: (performerData["performanceTypes"] as List)
                    .map((type) => Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 3.w, vertical: 1.h),
                          decoration: BoxDecoration(
                            color:
                                AppTheme.primaryOrange.withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color:
                                  AppTheme.primaryOrange.withValues(alpha: 0.5),
                            ),
                          ),
                          child: Text(
                            type as String,
                            style: AppTheme.darkTheme.textTheme.bodyMedium
                                ?.copyWith(
                              color: AppTheme.primaryOrange,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ))
                    .toList(),
              ),
            ),

          // Performance Schedule
          if (performerData["schedule"] != null)
            _buildSection(
              "Performance Schedule",
              Column(
                children: (performerData["schedule"] as List)
                    .map((schedule) => Container(
                          margin: EdgeInsets.only(bottom: 1.h),
                          padding: EdgeInsets.all(3.w),
                          decoration: AppTheme.performerCardDecoration(),
                          child: Row(
                            children: [
                              CustomIconWidget(
                                iconName: 'schedule',
                                color: AppTheme.primaryOrange,
                                size: 20,
                              ),
                              SizedBox(width: 3.w),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      (schedule as Map<String, dynamic>)["day"]
                                              as String? ??
                                          "",
                                      style: AppTheme
                                          .darkTheme.textTheme.titleSmall,
                                    ),
                                    Text(
                                      "${schedule["time"]} at ${schedule["location"]}",
                                      style: AppTheme
                                          .darkTheme.textTheme.bodySmall,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ))
                    .toList(),
              ),
            ),

          // Frequent Locations
          if (performerData["frequentLocations"] != null)
            _buildSection(
              "Frequent Locations",
              Column(
                children: (performerData["frequentLocations"] as List)
                    .map((location) => Container(
                          margin: EdgeInsets.only(bottom: 1.h),
                          padding: EdgeInsets.all(3.w),
                          decoration: AppTheme.performerCardDecoration(),
                          child: Row(
                            children: [
                              CustomIconWidget(
                                iconName: 'location_on',
                                color: AppTheme.primaryOrange,
                                size: 20,
                              ),
                              SizedBox(width: 3.w),
                              Expanded(
                                child: Text(
                                  location as String,
                                  style:
                                      AppTheme.darkTheme.textTheme.bodyMedium,
                                ),
                              ),
                            ],
                          ),
                        ))
                    .toList(),
              ),
            ),

          // Social Media Links
          if (performerData["socialMedia"] != null)
            _buildSection(
              "Social Media",
              Column(
                children: (performerData["socialMedia"] as Map<String, dynamic>)
                    .entries
                    .map((entry) => Container(
                          margin: EdgeInsets.only(bottom: 1.h),
                          child: InkWell(
                            onTap: () {
                              // Handle social media link tap
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text("Opening ${entry.key}..."),
                                  duration: const Duration(seconds: 2),
                                ),
                              );
                            },
                            child: Container(
                              padding: EdgeInsets.all(3.w),
                              decoration: AppTheme.performerCardDecoration(),
                              child: Row(
                                children: [
                                  CustomIconWidget(
                                    iconName: _getSocialMediaIcon(entry.key),
                                    color: AppTheme.primaryOrange,
                                    size: 20,
                                  ),
                                  SizedBox(width: 3.w),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          entry.key.toUpperCase(),
                                          style: AppTheme
                                              .darkTheme.textTheme.titleSmall,
                                        ),
                                        Text(
                                          entry.value as String,
                                          style: AppTheme
                                              .darkTheme.textTheme.bodySmall
                                              ?.copyWith(
                                            color: AppTheme.primaryOrange,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  CustomIconWidget(
                                    iconName: 'open_in_new',
                                    color: AppTheme.textSecondary,
                                    size: 16,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ))
                    .toList(),
              ),
            ),

          // Stats Section
          _buildSection(
            "Statistics",
            Container(
              padding: EdgeInsets.all(4.w),
              decoration: AppTheme.performerCardDecoration(),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildStatItem(
                          "Total Videos",
                          (performerData["videoCount"] as int? ?? 0)
                              .toString()),
                      _buildStatItem(
                          "Total Views",
                          _formatCount(
                              performerData["totalViews"] as int? ?? 0)),
                    ],
                  ),
                  SizedBox(height: 2.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildStatItem(
                          "Total Likes",
                          _formatCount(
                              performerData["totalLikes"] as int? ?? 0)),
                      _buildStatItem(
                          "Member Since",
                          _formatJoinDate(
                              performerData["joinDate"] as String? ?? "")),
                    ],
                  ),
                ],
              ),
            ),
          ),

          SizedBox(height: 4.h),
        ],
      ),
    );
  }

  Widget _buildSection(String title, Widget content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 2.h),
        content,
        SizedBox(height: 3.h),
      ],
    );
  }

  Widget _buildStatItem(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          value,
          style: AppTheme.performerStatsStyle(isLight: false).copyWith(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 0.5.h),
        Text(
          label,
          style: AppTheme.darkTheme.textTheme.bodySmall,
        ),
      ],
    );
  }

  String _getSocialMediaIcon(String platform) {
    switch (platform.toLowerCase()) {
      case 'instagram':
        return 'camera_alt';
      case 'tiktok':
        return 'music_note';
      case 'youtube':
        return 'play_circle_filled';
      case 'twitter':
        return 'alternate_email';
      default:
        return 'link';
    }
  }

  String _formatCount(int count) {
    if (count >= 1000000) {
      return "${(count / 1000000).toStringAsFixed(1)}M";
    } else if (count >= 1000) {
      return "${(count / 1000).toStringAsFixed(1)}K";
    }
    return count.toString();
  }

  String _formatJoinDate(String dateString) {
    if (dateString.isEmpty) return "Unknown";
    try {
      final date = DateTime.parse(dateString);
      final now = DateTime.now();
      final difference = now.difference(date);

      if (difference.inDays >= 365) {
        return "${(difference.inDays / 365).floor()} year${(difference.inDays / 365).floor() > 1 ? 's' : ''} ago";
      } else if (difference.inDays >= 30) {
        return "${(difference.inDays / 30).floor()} month${(difference.inDays / 30).floor() > 1 ? 's' : ''} ago";
      } else {
        return "${difference.inDays} day${difference.inDays > 1 ? 's' : ''} ago";
      }
    } catch (e) {
      return "Unknown";
    }
  }
}
