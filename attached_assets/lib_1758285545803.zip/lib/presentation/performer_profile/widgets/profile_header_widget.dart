import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ProfileHeaderWidget extends StatelessWidget {
  final Map<String, dynamic> performerData;
  final bool isFollowing;
  final VoidCallback onFollowTap;

  const ProfileHeaderWidget({
    super.key,
    required this.performerData,
    required this.isFollowing,
    required this.onFollowTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: AppTheme.darkTheme.scaffoldBackgroundColor,
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowDark,
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              // Profile Avatar
              Container(
                width: 20.w,
                height: 20.w,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: AppTheme.primaryOrange,
                    width: 2,
                  ),
                ),
                child: ClipOval(
                  child: CustomImageWidget(
                    imageUrl: performerData["avatar"] as String? ?? "",
                    width: 20.w,
                    height: 20.w,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              SizedBox(width: 4.w),
              // Profile Info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      performerData["name"] as String? ?? "Unknown Performer",
                      style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 0.5.h),
                    if (performerData["verificationStatus"] == "verified")
                      Row(
                        children: [
                          CustomIconWidget(
                            iconName: 'verified',
                            color: AppTheme.primaryOrange,
                            size: 16,
                          ),
                          SizedBox(width: 1.w),
                          Text(
                            "Verified Performer",
                            style: AppTheme.darkTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme.primaryOrange,
                            ),
                          ),
                        ],
                      ),
                    if (performerData["verificationStatus"] == "pending")
                      Row(
                        children: [
                          CustomIconWidget(
                            iconName: 'schedule',
                            color: AppTheme.textSecondary,
                            size: 16,
                          ),
                          SizedBox(width: 1.w),
                          Text(
                            "Verification Pending",
                            style: AppTheme.darkTheme.textTheme.bodySmall,
                          ),
                        ],
                      ),
                  ],
                ),
              ),
              // Follow Button
              ElevatedButton(
                onPressed: onFollowTap,
                style: ElevatedButton.styleFrom(
                  backgroundColor: isFollowing
                      ? AppTheme.darkTheme.colorScheme.surface
                      : AppTheme.primaryOrange,
                  foregroundColor: isFollowing
                      ? AppTheme.textPrimary
                      : AppTheme.backgroundDark,
                  padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                    side: isFollowing
                        ? const BorderSide(color: AppTheme.borderSubtle)
                        : BorderSide.none,
                  ),
                ),
                child: Text(
                  isFollowing ? "Following" : "Follow",
                  style: AppTheme.darkTheme.textTheme.labelLarge,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          // Stats Row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildStatColumn(
                "Videos",
                (performerData["videoCount"] as int? ?? 0).toString(),
              ),
              _buildStatColumn(
                "Followers",
                _formatCount(performerData["followersCount"] as int? ?? 0),
              ),
              _buildStatColumn(
                "Following",
                _formatCount(performerData["followingCount"] as int? ?? 0),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          // Performance Type Tags
          if (performerData["performanceTypes"] != null)
            Wrap(
              spacing: 2.w,
              runSpacing: 1.h,
              children: (performerData["performanceTypes"] as List)
                  .map((type) => Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 3.w, vertical: 0.5.h),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryOrange.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color:
                                AppTheme.primaryOrange.withValues(alpha: 0.5),
                          ),
                        ),
                        child: Text(
                          type as String,
                          style:
                              AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.primaryOrange,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ))
                  .toList(),
            ),
          if (performerData["frequentLocations"] != null) SizedBox(height: 1.h),
          // Frequent Locations
          if (performerData["frequentLocations"] != null)
            Wrap(
              spacing: 2.w,
              runSpacing: 1.h,
              children: (performerData["frequentLocations"] as List)
                  .take(3)
                  .map((location) => Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CustomIconWidget(
                            iconName: 'location_on',
                            color: AppTheme.textSecondary,
                            size: 14,
                          ),
                          SizedBox(width: 1.w),
                          Text(
                            location as String,
                            style: AppTheme.darkTheme.textTheme.bodySmall,
                          ),
                        ],
                      ))
                  .toList(),
            ),
          if (performerData["bio"] != null &&
              (performerData["bio"] as String).isNotEmpty)
            SizedBox(height: 2.h),
          // Bio
          if (performerData["bio"] != null &&
              (performerData["bio"] as String).isNotEmpty)
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                performerData["bio"] as String,
                style: AppTheme.darkTheme.textTheme.bodyMedium,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildStatColumn(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: AppTheme.performerStatsStyle(isLight: false).copyWith(
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 0.5.h),
        Text(
          label,
          style: AppTheme.darkTheme.textTheme.bodySmall,
        ),
      ],
    );
  }

  String _formatCount(int count) {
    if (count >= 1000000) {
      return "${(count / 1000000).toStringAsFixed(1)}M";
    } else if (count >= 1000) {
      return "${(count / 1000).toStringAsFixed(1)}K";
    }
    return count.toString();
  }
}
