import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class CameraControlsWidget extends StatelessWidget {
  final VoidCallback? onCapturePressed;
  final VoidCallback? onFlipCamera;
  final VoidCallback? onFlashToggle;
  final bool isRecording;
  final bool isFlashOn;
  final String recordingTime;

  const CameraControlsWidget({
    super.key,
    this.onCapturePressed,
    this.onFlipCamera,
    this.onFlashToggle,
    required this.isRecording,
    required this.isFlashOn,
    required this.recordingTime,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Back button (top-left, where flash button was)
        Positioned(
          top: 8.h,
          left: 4.w,
          child: GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 12.w,
              height: 6.h,
              decoration: BoxDecoration(
                color: AppTheme.videoOverlay,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Center(
                child: CustomIconWidget(
                  iconName: 'arrow_back',
                  color: AppTheme.textPrimary,
                  size: 24,
                ),
              ),
            ),
          ),
        ),

        // Timer display (above record button)
        Positioned(
          bottom: 24.h,
          left: 0,
          right: 0,
          child: Center(
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
              decoration: BoxDecoration(
                color: isRecording ? AppTheme.accentRed : AppTheme.videoOverlay,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (isRecording) ...[
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        color: AppTheme.textPrimary,
                        shape: BoxShape.circle,
                      ),
                    ),
                    SizedBox(width: 2.w),
                  ],
                  Text(
                    recordingTime,
                    style: AppTheme.videoOverlayStyle(),
                  ),
                ],
              ),
            ),
          ),
        ),

        // Flip camera (top-right)
        Positioned(
          top: 8.h,
          right: 4.w,
          child: GestureDetector(
            onTap: onFlipCamera,
            child: Container(
              width: 12.w,
              height: 6.h,
              decoration: BoxDecoration(
                color: AppTheme.videoOverlay,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Center(
                child: CustomIconWidget(
                  iconName: 'flip_camera_ios',
                  color: AppTheme.textPrimary,
                  size: 24,
                ),
              ),
            ),
          ),
        ),

        // Capture button (bottom-center)
        Positioned(
          bottom: 12.h,
          left: 0,
          right: 0,
          child: Center(
            child: GestureDetector(
              onTap: onCapturePressed,
              child: Container(
                width: 20.w,
                height: 10.h,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color:
                      isRecording ? AppTheme.accentRed : AppTheme.primaryOrange,
                  border: Border.all(
                    color: AppTheme.textPrimary,
                    width: 4,
                  ),
                ),
                child: Center(
                  child: Container(
                    width: isRecording ? 8.w : 16.w,
                    height: isRecording ? 4.h : 8.h,
                    decoration: BoxDecoration(
                      color: AppTheme.textPrimary,
                      borderRadius: BorderRadius.circular(isRecording ? 4 : 50),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
