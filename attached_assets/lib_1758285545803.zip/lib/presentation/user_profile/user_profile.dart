import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/activity_item_widget.dart';
import './widgets/performer_stats_widget.dart';
import './widgets/profile_header_widget.dart';
import './widgets/profile_section_widget.dart';
import './widgets/supporter_stats_widget.dart';

class UserProfile extends StatefulWidget {
  const UserProfile({super.key});

  @override
  State<UserProfile> createState() => _UserProfileState();
}

class _UserProfileState extends State<UserProfile> {
  // Mock user data
  final Map<String, dynamic> userData = {
    "id": 1,
    "name": "Marcus Rodriguez",
    "email": "marcus.street@ynfny.com",
    "avatar":
        "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400",
    "accountType": "performer", // or "new_yorker"
    "joinDate": "2024-01-15",
    "isVerified": true,
    "totalEarnings": 2847.50,
    "followerCount": 1234,
    "videoCount": 67,
    "monthlyEarnings": 485.20,
    "totalDonated": 156.75,
    "performersSupported": 12,
    "favoritePerformanceTypes": ["Music", "Dance", "Street Art"],
  };

  // Mock recent activities
  final List<Map<String, dynamic>> recentActivities = [
    {
      "id": 1,
      "type": "donation_received",
      "userName": "Sarah Chen",
      "amount": 15.0,
      "timestamp": DateTime.now().subtract(const Duration(hours: 2)),
    },
    {
      "id": 2,
      "type": "like",
      "userName": "Mike Johnson",
      "timestamp": DateTime.now().subtract(const Duration(hours: 4)),
    },
    {
      "id": 3,
      "type": "follow",
      "userName": "Emma Davis",
      "timestamp": DateTime.now().subtract(const Duration(hours: 6)),
    },
    {
      "id": 4,
      "type": "comment",
      "userName": "Alex Thompson",
      "timestamp": DateTime.now().subtract(const Duration(days: 1)),
    },
    {
      "id": 5,
      "type": "donation_received",
      "userName": "Lisa Park",
      "amount": 25.0,
      "timestamp": DateTime.now().subtract(const Duration(days: 2)),
    },
  ];

  @override
  Widget build(BuildContext context) {
    final isPerformer =
        (userData["accountType"] as String? ?? "new_yorker") == "performer";

    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      appBar: AppBar(
        backgroundColor: AppTheme.backgroundDark,
        elevation: 0,
        iconTheme: const IconThemeData(
          color: Colors.white,
        ),
        title: Text(
          "Profile",
          style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w600,
          ),
        ),
        actions: [
          IconButton(
            onPressed: _showLogoutDialog,
            icon: CustomIconWidget(
              iconName: 'logout',
              color: AppTheme.textSecondary,
              size: 6.w,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Profile Header
            ProfileHeaderWidget(
              userData: userData,
              onAvatarTap: _showAvatarOptions,
            ),

            SizedBox(height: 3.h),

            // Stats Section (Role-specific)
            if (isPerformer)
              PerformerStatsWidget(performerData: userData)
            else
              SupporterStatsWidget(supporterData: userData),

            SizedBox(height: 3.h),

            // Account Section
            ProfileSectionWidget(
              title: "Account",
              items: _getAccountItems(),
              onItemTap: _handleSectionTap,
            ),

            // Activity Section
            ProfileSectionWidget(
              title: "Activity",
              items: _getActivityItems(),
              onItemTap: _handleSectionTap,
            ),

            // Recent Activity List
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(4.w),
              decoration: AppTheme.performerCardDecoration(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Recent Activity",
                    style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                      color: AppTheme.primaryOrange,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 2.h),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: recentActivities.length,
                    itemBuilder: (context, index) {
                      return ActivityItemWidget(
                        activity: recentActivities[index],
                      );
                    },
                  ),
                ],
              ),
            ),

            SizedBox(height: 3.h),

            // Support Section
            ProfileSectionWidget(
              title: "Support",
              items: _getSupportItems(),
              onItemTap: _handleSectionTap,
            ),

            // Settings Section
            ProfileSectionWidget(
              title: "Settings",
              items: _getSettingsItems(),
              onItemTap: _handleSectionTap,
            ),

            SizedBox(height: 10.h), // Bottom padding for navigation
          ],
        ),
      ),
    );
  }

  List<Map<String, dynamic>> _getAccountItems() {
    return [
      {
        "icon": "edit",
        "title": "Edit Profile",
        "subtitle": "Update your profile information",
        "route": "/edit-profile",
      },
      {
        "icon": "notifications",
        "title": "Notification Preferences",
        "subtitle": "Manage your notification settings",
        "route": "/notification-settings",
        "showBadge": true,
      },
      {
        "icon": "payment",
        "title": "Payment Methods",
        "subtitle": "Manage cards and payout settings",
        "route": "/payment-methods",
      },
      {
        "icon": "privacy_tip",
        "title": "Privacy Settings",
        "subtitle": "Control your privacy and data",
        "route": "/privacy-settings",
      },
    ];
  }

  List<Map<String, dynamic>> _getActivityItems() {
    return [
      {
        "icon": "favorite",
        "title": "Likes Received",
        "subtitle": "See who liked your content",
        "route": "/likes-received",
      },
      {
        "icon": "chat_bubble",
        "title": "Comments",
        "subtitle": "View and manage comments",
        "route": "/comments",
      },
      {
        "icon": "people",
        "title": "Followers",
        "subtitle": "Manage your followers",
        "route": "/followers",
      },
      {
        "icon": "history",
        "title": "Transaction History",
        "subtitle": "View donation history",
        "route": "/transaction-history",
      },
    ];
  }

  List<Map<String, dynamic>> _getSupportItems() {
    return [
      {
        "icon": "help",
        "title": "Help Center",
        "subtitle": "Get help and support",
        "route": "/help-center",
      },
      {
        "icon": "contact_support",
        "title": "Contact Us",
        "subtitle": "Reach out to our team",
        "route": "/contact-support",
      },
      {
        "icon": "gavel",
        "title": "Community Guidelines",
        "subtitle": "Read our community rules",
        "route": "/community-guidelines",
      },
    ];
  }

  List<Map<String, dynamic>> _getSettingsItems() {
    return [
      {
        "icon": "settings",
        "title": "App Preferences",
        "subtitle": "Customize your app experience",
        "route": "/app-preferences",
      },
      {
        "icon": "data_usage",
        "title": "Data Usage",
        "subtitle": "Manage data and storage",
        "route": "/data-usage",
      },
      {
        "icon": "delete_forever",
        "title": "Delete Account",
        "subtitle": "Permanently delete your account",
        "route": "/delete-account",
      },
    ];
  }

  void _handleSectionTap(String route) {
    if (route.isNotEmpty) {
      // Handle navigation to different sections
      switch (route) {
        case "/edit-profile":
          _navigateToEditProfile();
          break;
        case "/notification-settings":
          _showNotificationSettings();
          break;
        case "/payment-methods":
          _showPaymentMethods();
          break;
        case "/delete-account":
          _showDeleteAccountDialog();
          break;
        default:
          _showComingSoon(route);
          break;
      }
    }
  }

  void _navigateToEditProfile() {
    // Navigate to edit profile screen
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          "Edit Profile feature coming soon",
          style: AppTheme.darkTheme.textTheme.bodyMedium,
        ),
        backgroundColor: AppTheme.surfaceDark,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showAvatarOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.surfaceDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.borderSubtle,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              "Change Profile Photo",
              style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                color: AppTheme.textPrimary,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 3.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'camera_alt',
                color: AppTheme.primaryOrange,
                size: 6.w,
              ),
              title: Text(
                "Take Photo",
                style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.textPrimary,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                _showComingSoon("Camera");
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'photo_library',
                color: AppTheme.primaryOrange,
                size: 6.w,
              ),
              title: Text(
                "Choose from Gallery",
                style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.textPrimary,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                _showComingSoon("Gallery");
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  void _showNotificationSettings() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surfaceDark,
        title: Text(
          "Notification Settings",
          style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SwitchListTile(
              title: Text(
                "Push Notifications",
                style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.textPrimary,
                ),
              ),
              subtitle: Text(
                "Receive notifications on your device",
                style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.textSecondary,
                ),
              ),
              value: true,
              onChanged: (value) {},
            ),
            SwitchListTile(
              title: Text(
                "Email Updates",
                style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.textPrimary,
                ),
              ),
              subtitle: Text(
                "Get updates via email",
                style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.textSecondary,
                ),
              ),
              value: false,
              onChanged: (value) {},
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Close",
              style: TextStyle(color: AppTheme.primaryOrange),
            ),
          ),
        ],
      ),
    );
  }

  void _showPaymentMethods() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surfaceDark,
        title: Text(
          "Payment Methods",
          style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Text(
          "Manage your payment methods and payout settings. This feature integrates with Stripe for secure transactions.",
          style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.textPrimary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Close",
              style: TextStyle(color: AppTheme.primaryOrange),
            ),
          ),
        ],
      ),
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surfaceDark,
        title: Text(
          "Logout",
          style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Text(
          "Are you sure you want to logout? Your data will be retained for when you return.",
          style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.textPrimary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Cancel",
              style: TextStyle(color: AppTheme.textSecondary),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              AppRoutes.pushReplacementNamed(
                context,
                AppRoutes.loginScreen,
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.accentRed,
            ),
            child: Text(
              "Logout",
              style: TextStyle(color: AppTheme.textPrimary),
            ),
          ),
        ],
      ),
    );
  }

  void _showDeleteAccountDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surfaceDark,
        title: Text(
          "Delete Account",
          style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
            color: AppTheme.accentRed,
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Text(
          "This action cannot be undone. All your data, videos, and earnings will be permanently deleted.",
          style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.textPrimary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Cancel",
              style: TextStyle(color: AppTheme.textSecondary),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showComingSoon("Account Deletion");
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.accentRed,
            ),
            child: Text(
              "Delete",
              style: TextStyle(color: AppTheme.textPrimary),
            ),
          ),
        ],
      ),
    );
  }

  void _showComingSoon(String feature) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          "$feature feature coming soon",
          style: AppTheme.darkTheme.textTheme.bodyMedium,
        ),
        backgroundColor: AppTheme.surfaceDark,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
