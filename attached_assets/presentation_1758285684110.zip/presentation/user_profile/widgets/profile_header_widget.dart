import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ProfileHeaderWidget extends StatelessWidget {
  final Map<String, dynamic> userData;
  final VoidCallback onAvatarTap;

  const ProfileHeaderWidget({
    super.key,
    required this.userData,
    required this.onAvatarTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: AppTheme.glassmorphismDecoration(),
      child: Column(
        children: [
          Row(
            children: [
              GestureDetector(
                onTap: onAvatarTap,
                child: Container(
                  width: 20.w,
                  height: 20.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: AppTheme.primaryOrange,
                      width: 2,
                    ),
                  ),
                  child: ClipOval(
                    child: CustomImageWidget(
                      imageUrl: userData["avatar"] as String? ?? "",
                      width: 20.w,
                      height: 20.w,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 4.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      userData["name"] as String? ?? "Unknown User",
                      style: AppTheme.darkTheme.textTheme.titleLarge,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 1.h),
                    Container(
                      padding: EdgeInsets.symmetric(
                          horizontal: 3.w, vertical: 0.5.h),
                      decoration: BoxDecoration(
                        color: (userData["accountType"] as String? ??
                                    "new_yorker") ==
                                "performer"
                            ? AppTheme.primaryOrange.withValues(alpha: 0.2)
                            : AppTheme.accentRed.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: (userData["accountType"] as String? ??
                                      "new_yorker") ==
                                  "performer"
                              ? AppTheme.primaryOrange
                              : AppTheme.accentRed,
                          width: 1,
                        ),
                      ),
                      child: Text(
                        (userData["accountType"] as String? ?? "new_yorker") ==
                                "performer"
                            ? "Street Performer"
                            : "New Yorker",
                        style:
                            AppTheme.darkTheme.textTheme.labelMedium?.copyWith(
                          color: (userData["accountType"] as String? ??
                                      "new_yorker") ==
                                  "performer"
                              ? AppTheme.primaryOrange
                              : AppTheme.accentRed,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
